import Uploader from "./uploader";
import adapter from "./adapter"

export default Uploader;