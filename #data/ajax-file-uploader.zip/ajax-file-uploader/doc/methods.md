> jquery-upload 的方法

* `upload` 上传所有待上传文件，适用于手动模式
* `clean` 清除所有文件
* `uploadFiles` 获取所有文件